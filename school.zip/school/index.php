<?php $con=mysqli_connect("localhost","root","1990","school"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Special School</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css"><![endif]-->
</head>
<body>
<div id="header">
  <div> <a href="index.php"><img src="images/logo.gif" alt=""></a>
    <ul>
      <li class="current"><a href="index.php">Home</a></li>
      <li><a href="about.php">About us</a></li>
      <li><a href="services.php">Services</a></li>
      <li><a href="blog.php">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
</div>
<div id="content">
  <div>
    <div>

    <?php
    $qry=mysqli_query($con,"SELECT * FROM `s_school` order by id DESC");
    $row=mysqli_fetch_array($qry);
    extract($row);
    ?>
      <h1><?php echo $title; ?></h1>
      <p><?php  echo $content; ?></p>

    <?php
    $qry=mysqli_query($con,"SELECT * FROM `special` order by id DESC");
    $row=mysqli_fetch_array($qry);
    extract($row);
    ?>
      <h1><?php echo $title; ?></h1>
      <p><?php  echo $content; ?></p>
    </div>
  </div>
</div>
<div id="footer">
  <div>
    <div> <span>Follow us</span> <a href="#" class="facebook">Facebook</a> <a href="#" class="subscribe">Subscribe</a> <a href="#" class="twitter">Twitter</a> <a href="#" class="flicker">Flickr</a> </div>
    <ul>
      <li> <a href="#"><img src="images/playing-in-grass.gif" alt=""></a>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
        <a href="#" class="readmore">Read more</a> </li>
      <li> <a href="#"><img src="images/baby-smiling.gif" alt=""></a>
        <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud.</p>
        <a href="#" class="readmore">Read more</a> </li>
    </ul>
  </div>
  <p class="footnote">Copyright &copy; 2017 <a href="#">School Name</a> All rights reserved | Suman Kumar <a target="_blank" href="#">suman@gmail.com</a></p>
</div>
</body>
</html>
