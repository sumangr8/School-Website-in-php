<?php

$dbconfig=mysqli_connect("localhost","root","1990","school");

$start=0;
$limit=2;

if(isset($_GET['id']))
{
  $id=$_GET['id'];
  $start=($id-1)*$limit;
}
else{
  $id=1;
}
//Fetch from database first 10 items which is its limit. For that when page open you can see first 10 items. 
$query=mysqli_query($dbconfig,"select * from blog LIMIT $start, $limit");
?>



<?php
//fetch all the data from database.
$rows=mysqli_num_rows(mysqli_query($dbconfig,"select * from blog"));
//calculate total page number for the given table in the database 
$total=ceil($rows/$limit);?>

<?php if($id>1)
{
  
  //echo "<li><a href='?id=".($id-1)."' class='button'>PREVIOUS</a></li>";
}
if($id!=$total)
{
  
  //echo "<li><a href='?id=".($id+1)."' class='button'>NEXT</a></li>";
}
?>


<!DOCTYPE html>
<html>
<head>
<title>Special School | Blog</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css"><![endif]-->
</head>
<body>
<div id="header">
  <div> <a href="index.php"><img src="images/logo.gif" alt=""></a>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About us</a></li>
      <li><a href="services.php">Services</a></li>
      <li class="current"><a href="blog.php">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
</div>
<div class="content">
  <div id="blog">
    <div class="sidebar">
      <h2>Archives</h2>
      <h3 class="first"><a href="#">2011 <span>(60)</span></a></h3>
      <div>
          <?php 
          $con=mysqli_connect("localhost","root","1990","school");
          $m_qry=mysqli_query($con,"select * from month");
          while($m_row=mysqli_fetch_array($m_qry))
          {
            extract($m_row);
          ?>

        <p><a href="blog.php?month_id=<?php echo $month_id; ?>"><?php echo $month; ?></a></p>
        <?php
          }
          ?>
        <!-- <p><a href="#">November <span>(11)</span></a></p>
        <p><a href="#">October <span>(3)</span></a></p>
        <p><a href="#">September <span>(8)</span></a></p>
        <p><a href="#">August <span>(2)</span></a></p>
        <p><a href="#">July <span>(3)</span></a></p>
        <p><a href="#">June </a></p>
        <p><a href="#">May <span>(8)</span></a></p>
        <p><a href="#">April <span>(7)</span></a></p>
        <p><a href="#">March <span>(7)</span></a></p>
        <p><a href="#">February <span>(10)</span></a></p>
        <p><a href="#">January <span>(1)</span></a></p> -->
      </div>
      <!-- <h3><a href="#">2010</a></h3>
      <h3><a href="#">2009</a></h3> -->
    </div>
    <div class="article">
    <?php
    if(!isset($_GET["month_id"]))
    {
    $query=mysqli_query($dbconfig,"select * from blog LIMIT $start, $limit");
    while($result=mysqli_fetch_array($query))
    {
      extract($result);
    ?>

      <ul>
        <li class="first">
          <div class="section"> <a href="#"><img src="admin/blog-img/<?php echo $pic; ?>" width="80" height="80" alt=""></a> <span><a href="#"><?php echo $name; ?></a></span> <span><a href="#">Dec 3</a></span> </div>
          <div>
            <h1><a href="#"><?php echo $title; ?></a></h1>
            <p><?php echo $content; ?>.</p>
          </div>
        </li>
        
      </ul>
      <?php
    }
  }
    ?>

  <!--if click month-->
  <?php
    if(isset($_GET["month_id"]))
    {
      $month_id=$_GET["month_id"];
    $query=mysqli_query($dbconfig,"select * from blog where month='$month_id' LIMIT $start, $limit");
    while($result=mysqli_fetch_array($query))
    {
      extract($result);
    ?>

      <ul>
        <li class="first">
          <div class="section"> <a href="#"><img src="admin/blog-img/<?php echo $pic; ?>" width="80" height="80" alt=""></a> <span><a href="#"><?php echo $name; ?></a></span> <span><a href="#">Dec 3</a></span> </div>
          <div>
            <h1><a href="#"><?php echo $title; ?></a></h1>
            <p><?php echo $content; ?>.</p>
          </div>
        </li>
        
      </ul>
      <?php
    }
  }
    ?>

    <?php
            //show all the page link with page number. When click on these numbers go to particular page. 
            for($i=1;$i<=$total;$i++)
            {
            if($i==$id) { echo $i; }

            else { echo "<a href='?id=".$i."'>".$i."</a>"; }
            }
            ?>
      <div id="paging">
        <ul>
          <li class="selected">
            

          </li>
          <!-- <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#">4</a></li> -->
        </ul>
         </div>
    </div>
  </div>
</div>
<div id="footer">
  <div>
    <div> <span>Follow us</span> <a href="#" class="facebook">Facebook</a> <a href="#" class="subscribe">Subscribe</a> <a href="#" class="twitter">Twitter</a> <a href="#" class="flicker">Flickr</a> </div>
    <ul>
      <li> <a href="#"><img src="images/playing-in-grass.gif" alt=""></a>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
        <a href="#" class="readmore">Read more</a> </li>
      <li> <a href="#"><img src="images/baby-smiling.gif" alt=""></a>
        <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud.</p>
        <a href="#" class="readmore">Read more</a> </li>
    </ul>
  </div>
  <p class="footnote">Copyright &copy; 2017 <a href="#">School Name</a> All rights reserved | Suman Kumar <a target="_blank" href="#">suman@gmail.com</a></p>
</div>
</body>
</html>
