<?php
$con=mysqli_connect("localhost","root","1990","school");
$qry=mysqli_query($con,"SELECT `id`, `v_title`, `v_content`, `m_title`, `m_content`, `c_title`, `c_content` FROM `education` order by id DESC");
$row=mysqli_fetch_array($qry);
extract($row);
?>
<!DOCTYPE html>
<html>
<head>
<title>Special School | Services</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css"><![endif]-->
</head>
<body>
<div id="header">
  <div> <a href="index.php"><img src="images/logo.gif" alt=""></a>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About us</a></li>
      <li class="current"><a href="services.php">Services</a></li>
      <li><a href="blog.php">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
</div>
<div class="content">
  <div>
    <div> <img src="images/baby.jpg" alt=""> </div>
    <div id="services">
      <div id="sidebar">
        <h3>Our Education</h3>
        <ul>
          <li id="vision"> <span><?php echo $v_title; ?></span>
            <p><?php echo $v_content; ?>.</p>
          </li>
          <li id="mission"> <span><?php echo $m_title; ?></span>
            <p><?php echo $m_content; ?>.</p>
          </li>
          <li id="wecare"> <span><?php echo $c_title; ?></span>
            <p><?php echo $c_content; ?>.</p>
          </li>
        </ul>
      </div>

      <!--Start Our Mission-->
      <div id="aside"> <span class="first"><?php echo $m_title; ?></span>
      <?php
      $qry1=mysqli_query($con,"select * from methods");
      while($row1=mysqli_fetch_array($qry1))
      {
        extract($row1);
        $m_title=$row1["title"];
      ?>
      
        <ul class="section">
          <li><?php echo $list; ?></li>
          
        </ul>
        <?php
        }
        ?>
        <!-- End Our Mission-->
        <span>Common Special needs include:</span>
          <?php
        $qry1=mysqli_query($con,"select * from special_needs");
        while($row1=mysqli_fetch_array($qry1))
        {
          extract($row1);
          
        ?>
         <b>~ <?php echo $s_list;  ?></b>
         <?php
          }
         ?>
         <span>Our Services</span>
        <div>
          <ol>
            <li>Speech and Language Pathology</li>
            <li>Audiology</li>
            <li>Psychological Services</li>
            <li>Physical Therapy</li>
            <li>Occupation Therapy</li>
            <li>Counseling Services</li>
            <li>Rehabilitation Counseling</li>
            <li>Orientation and Mobility Services</li>
          </ol>
          <ol>
            <li>School Social Work</li>
            <li>Assistive Technology Services</li>
            <li>Corrective Support Services</li>
            <li>Developmental Recreation Activities</li>
            <li>School Health Services</li>
            <li>Parent Counseling and Training</li>
            <li>Medical Services</li>
          </ol>
        </div>
      </div>
      <!--For Start File-->
        <table align="center" border="1">
        <tr>
        <td>Sr. No</td>
        <td>File</td>
        <td>Download</td>
        </tr>
        <?php
        $i=1;
        $con=mysqli_connect("localhost","root","1990","school");
        $qry=mysqli_query($con,"select * from file");
        while ($row=mysqli_fetch_array($qry)) 
        {
        // echo $row["name"];
        $id=$row["id"];
        echo "<tr>";
        echo "<td>".$i."</td>";++$i;

        echo "<td>".$row['file']."</td>";
        echo "<td><a href='admin/download.php?id=".$id."'>Download</td>";
        echo "</tr>";
        }
        ?>
        </table>

      <!--end File-->
    </div>
  </div>
</div>

<div id="footer">
  <div>
    <div> <span>Follow us</span> <a href="#" class="facebook">Facebook</a> <a href="#" class="subscribe">Subscribe</a> <a href="#" class="twitter">Twitter</a> <a href="#" class="flicker">Flickr</a> </div>
    <ul>
      <li> <a href="#"><img src="images/playing-in-grass.gif" alt=""></a>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
        <a href="#" class="readmore">Read more</a> </li>
      <li> <a href="#"><img src="images/baby-smiling.gif" alt=""></a>
        <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud.</p>
        <a href="#" class="readmore">Read more</a> </li>
    </ul>
  </div>
  <p class="footnote">Copyright &copy; 2017 <a href="#">School Name</a> All rights reserved | Suman Kumar <a target="_blank" href="#">suman@gmail.com</a></p>
</div>
</body>
</html>
