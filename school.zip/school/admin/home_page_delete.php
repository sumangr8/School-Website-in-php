<?php
$id=$_GET["id"];
echo $id;
$con=mysqli_connect("localhost","root","1990","school");
$qry=mysqli_query($con,"DELETE FROM `s_school` WHERE id='$id'");
if($qry)
{
	 echo "<script>window.open('home_page.php','_self')</script>";
}
?>