<?php
$id=$_GET["id"];
$con=mysqli_connect("localhost","root","1990","school");
$qry=mysqli_query($con,"DELETE FROM `our_services` WHERE id='$id'");
if($qry)
{
	echo "<script>window.open('service.php','_self')</script>";
}
?>