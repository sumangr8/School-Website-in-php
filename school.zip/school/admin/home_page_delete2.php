<?php
$id=$_GET["id"];
$con=mysqli_connect("localhost","root","1990","school");
$qry=mysqli_query($con,"DELETE FROM `special` WHERE id='$id'");
if($qry)
{
	echo "<script>window.open('home_page2.php','_self')</script>";
}
?>