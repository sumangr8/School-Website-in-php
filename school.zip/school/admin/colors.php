<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Bootflat-Admin Template</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="favicon_16.ico"/>
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- site css -->
    <link rel="stylesheet" href="dist/css/site.min.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
    <!-- <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'> -->
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="dist/js/site.min.js"></script>
  </head>
  <body>
    <!--nav-->
    <nav role="navigation" class="navbar navbar-custom">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button data-target="#bs-content-row-navbar-collapse-5" data-toggle="collapse" class="navbar-toggle" type="button">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">Bootflat-Admin</a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div id="bs-content-row-navbar-collapse-5" class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="getting-started.php">Getting Started</a></li>
              <li class="active"><a href="index.php">Documentation</a></li>
              <!-- <li class="disabled"><a href="#">Link</a></li> -->
              <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">Silverbux <b class="caret"></b></a>
                <ul role="menu" class="dropdown-menu">
                  <li class="dropdown-header">Setting</li>
                  <li><a href="#">Action</a></li>
                  <li class="divider"></li>
                  <li class="active"><a href="#">Separated link</a></li>
                  <li class="divider"></li>
                  <li class="disabled"><a href="#">Signout</a></li>
                </ul>
              </li>
            </ul>

          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
    <!--header-->
    <div class="container-fluid">
    <!--documents-->
        <div class="row row-offcanvas row-offcanvas-left">
          <div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
            <ul class="list-group panel">
                <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>SIDE PANEL</b></li>
                <li class="list-group-item"><input type="text" class="form-control search-query" placeholder="Search Something"></li>
                <li class="list-group-item"><a href="index.php"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
                <li class="list-group-item"><a href="home_page.php"><i class="glyphicon glyphicon-home"></i>Home Page </a>
                <a href="home_page2.php"><i class="glyphicon glyphicon-home"></i>Home Page </a></li>
                <li class="list-group-item"><a href="eduction.php"><i class="glyphicon glyphicon-certificate"></i>Eduction </a></li>
                <li class="list-group-item"><a href="service.php"><i class="glyphicon glyphicon-certificate"></i>Service </a></li>
                <li class="list-group-item"><a href="blog.php"><i class="glyphicon glyphicon-certificate"></i>Blog </a></li>
                <li class="list-group-item"><a href="icons.php"><i class="glyphicon glyphicon-certificate"></i>Icons </a></li>
                <li class="list-group-item"><a href="list.php"><i class="glyphicon glyphicon-th-list"></i>Tables and List </a></li>
                <li class="list-group-item"><a href="forms.php"><i class="glyphicon glyphicon-list-alt"></i>Forms</a></li>
                <li class="list-group-item"><a href="alerts.php"><i class="glyphicon glyphicon-bell"></i>Alerts</li>
                <li class="list-group-item"><a href="timeline.php" ><i class="glyphicon glyphicon-indent-left"></i>Timeline</a></li>
                <li class="list-group-item"><a href="calendars.php" ><i class="glyphicon glyphicon-calendar"></i>Calendars</a></li>
                <li class="list-group-item"><a href="typography.php" ><i class="glyphicon glyphicon-font"></i>Typography</a></li>
                <li class="list-group-item"><a href="footers.php" ><i class="glyphicon glyphicon-minus"></i>Footers</a></li>
                <li class="list-group-item"><a href="panels.php" ><i class="glyphicon glyphicon-list-alt"></i>Panels</a></li>
                <li class="list-group-item"><a href="navs.php" ><i class="glyphicon glyphicon-th-list"></i>Navs</a></li>
                <li class="list-group-item"><a href="colors.php" ><i class="glyphicon glyphicon-tint"></i>Colors</a></li>
                <li class="list-group-item"><a href="flex.php" ><i class="glyphicon glyphicon-th"></i>Flex</a></li>
                <li class="list-group-item"><a href="login.php" ><i class="glyphicon glyphicon-lock"></i>Login</a></li>
                <li>
                  <a href="#demo3" class="list-group-item " data-toggle="collapse">Item 3  <span class="glyphicon glyphicon-chevron-right"></span></a>
                  <div class="collapse" id="demo3">
                    <a href="#SubMenu1" class="list-group-item" data-toggle="collapse">Subitem 1  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <div class="collapse list-group-submenu" id="SubMenu1">
                      <a href="#" class="list-group-item">Subitem 1 a</a>
                      <a href="#" class="list-group-item">Subitem 2 b</a>
                      <a href="#SubSubMenu1" class="list-group-item" data-toggle="collapse">Subitem 3 c <span class="glyphicon glyphicon-chevron-right"></span></a>
                      <div class="collapse list-group-submenu list-group-submenu-1" id="SubSubMenu1">
                        <a href="#" class="list-group-item">Sub sub item 1</a>
                        <a href="#" class="list-group-item">Sub sub item 2</a>
                      </div>
                      <a href="#" class="list-group-item">Subitem 4 d</a>
                    </div>
                    <a href="javascript:;" class="list-group-item">Subitem 2</a>
                    <a href="javascript:;" class="list-group-item">Subitem 3</a>
                  </div>
                </li>
                <li>
                  <a href="#demo4" class="list-group-item " data-toggle="collapse">Item 4  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <li class="collapse" id="demo4">
                      <a href="" class="list-group-item">Subitem 1</a>
                      <a href="" class="list-group-item">Subitem 2</a>
                      <a href="" class="list-group-item">Subitem 3</a>
                    </li>
                </li>
              </ul>
          </div>
          <div class="col-xs-12 col-sm-9 content">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a> Panel Title</h3>
              </div>
              <div class="panel-body">
                <div class="content-row">
                  <h2 class="content-row-title">Colors</h2>
                  <div class="row">
                    <div class="col-md-12">

                      <div class="color-wrap clearfix">
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#C91F37;">
                            <span class="color-name">Foreign crimson</span>
                            <br>
                            <span class="hex-number">#C91F37</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#DC3023;">
                            <span class="color-name">Red orange</span>
                            <br>
                            <span class="hex-number">#DC3023</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#9D2933;">
                            <span class="color-name">Cochineal red</span>
                            <br>
                            <span class="hex-number">#9D2933</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#CF000F;">
                            <span class="color-name">Monza</span>
                            <br>
                            <span class="hex-number">#CF000F</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#E68364;">
                            <span class="color-name">Brewed mustard-brown</span>
                            <br>
                            <span class="hex-number">#E68364</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F22613;">
                            <span class="color-name">Pomegranate</span>
                            <br>
                            <span class="hex-number">#F22613</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#CF3A24;">
                            <span class="color-name">Scarlet</span>
                            <br>
                            <span class="hex-number">#CF3A24</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#C3272B;">
                            <span class="color-name">Pure crimson</span>
                            <br>
                            <span class="hex-number">#C3272B</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #8F1D21;">
                            <span class="color-name">True red</span>
                            <br>
                            <span class="hex-number">#8F1D21</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#D24D57;">
                            <span class="color-name">Chestnut Rose</span>
                            <br>
                            <span class="hex-number">#D24D57</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F08F90;">
                            <span class="color-name">One kin dye</span>
                            <br>
                            <span class="hex-number">#F08F907</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F47983;">
                            <span class="color-name">Peach-colored</span>
                            <br>
                            <span class="hex-number">#F47983</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#DB5A6B;">
                            <span class="color-name">Red plum colored</span>
                            <br>
                            <span class="hex-number">#DB5A6B</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#C93756;">
                            <span class="color-name">Medium crimson</span>
                            <br>
                            <span class="hex-number">#C93756</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FCC9B9;">
                            <span class="color-name">Cherry blossom color</span>
                            <br>
                            <span class="hex-number">#FCC9B9</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FFB3A7;">
                            <span class="color-name">Washed-out crimson</span>
                            <br>
                            <span class="hex-number">#FFB3A7</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F62459;">
                            <span class="color-name">RADICAL RED</span>
                            <br>
                            <span class="hex-number">#F62459</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F58F84;">
                            <span class="color-name">Ibis wing color</span>
                            <br>
                            <span class="hex-number">#F58F84</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#875F9A;">
                            <span class="color-name">Wisteria purple</span>
                            <br>
                            <span class="hex-number">#875F9A</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#5D3F6A;">
                            <span class="color-name">Bellflower color</span>
                            <br>
                            <span class="hex-number">#5D3F6A</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#89729E;">
                            <span class="color-name">Wisteria color</span>
                            <br>
                            <span class="hex-number">#89729E</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#763568;">
                            <span class="color-name">Iris color</span>
                            <br>
                            <span class="hex-number">#763568</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#8D608C;">
                            <span class="color-name">Tatarian aster color</span>
                            <br>
                            <span class="hex-number">#8D608C</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#A87CA0;">
                            <span class="color-name">Thin color</span>
                            <br>
                            <span class="hex-number">#A87CA0</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#5B3256;">
                            <span class="color-name">Violet color</span>
                            <br>
                            <span class="hex-number">#5B3256</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#BF55EC;">
                            <span class="color-name">MEDIUM PURPLE</span>
                            <br>
                            <span class="hex-number">#BF55EC</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #8E44AD;">
                            <span class="color-name">STUDIO</span>
                            <br>
                            <span class="hex-number">#8E44AD</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#9B59B6;">
                            <span class="color-name">WISTERIA</span>
                            <br>
                            <span class="hex-number">#9B59B6</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#BE90D4;">
                            <span class="color-name">LIGHT WISTERIA</span>
                            <br>
                            <span class="hex-number">#BE90D4</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#4D8FAC;">
                            <span class="color-name">Sky color</span>
                            <br>
                            <span class="hex-number">#4D8FAC</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#5D8CAE;">
                            <span class="color-name">Ultramarine color</span>
                            <br>
                            <span class="hex-number">#5D8CAE</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#22A7F0;">
                            <span class="color-name">PICTON BLUE</span>
                            <br>
                            <span class="hex-number">#22A7F0</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#19B5FE;">
                            <span class="color-name">DODGER BLUE</span>
                            <br>
                            <span class="hex-number">#19B5FE</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#59ABE3;">
                            <span class="color-name">PICTON BLUE</span>
                            <br>
                            <span class="hex-number">#59ABE3</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#48929B;">
                            <span class="color-name">Light blue color</span>
                            <br>
                            <span class="hex-number">#48929B</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#317589;">
                            <span class="color-name">Thousand herb</span>
                            <br>
                            <span class="hex-number">#317589</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#89C4F4;">
                            <span class="color-name">JORDY BLUE</span>
                            <br>
                            <span class="hex-number">#89C4F4</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #4B77BE;">
                            <span class="color-name">STEEL BLUE</span>
                            <br>
                            <span class="hex-number">#4B77BE</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#1F4788;">
                            <span class="color-name">Lapis lazuli color</span>
                            <br>
                            <span class="hex-number">#1F4788</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#003171;">
                            <span class="color-name">Navy blue color</span>
                            <br>
                            <span class="hex-number">#003171</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#044F67;">
                            <span class="color-name">Hanada</span>
                            <br>
                            <span class="hex-number">#044F67</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #264348;">
                            <span class="color-name">Indigo color</span>
                            <br>
                            <span class="hex-number">#264348</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#7A942E;">
                            <span class="color-name">Siskin sprout yellow</span>
                            <br>
                            <span class="hex-number">#7A942E</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#8DB255;">
                            <span class="color-name">young green onion</span>
                            <br>
                            <span class="hex-number">#8DB255</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#5B8930;">
                            <span class="color-name">Fresh onion</span>
                            <br>
                            <span class="hex-number">#5B8930</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#6B9362;">
                            <span class="color-name">Young bamboo color</span>
                            <br>
                            <span class="hex-number">#6B9362</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#407A52;">
                            <span class="color-name">Patina</span>
                            <br>
                            <span class="hex-number">#407A52</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#006442;">
                            <span class="color-name">Green bamboo</span>
                            <br>
                            <span class="hex-number">#006442</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#87D37C;">
                            <span class="color-name">GOSSIP</span>
                            <br>
                            <span class="hex-number">#87D37C</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#26A65B;">
                            <span class="color-name">EUCALYPTUS</span>
                            <br>
                            <span class="hex-number">#26A65B</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #26C281;">
                            <span class="color-name">JUNGLE GREEN</span>
                            <br>
                            <span class="hex-number">#26C281</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#049372;">
                            <span class="color-name">OBSERVATORY</span>
                            <br>
                            <span class="hex-number">#049372</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#2ABB9B;">
                            <span class="color-name">JUNGLE GREEN</span>
                            <br>
                            <span class="hex-number">#2ABB9B</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#16A085;">
                            <span class="color-name">MOUNTAIN MEADOW</span>
                            <br>
                            <span class="hex-number">#16A085</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#36D7B7;">
                            <span class="color-name">TURQUOISE</span>
                            <br>
                            <span class="hex-number">#36D7B7</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #03A678;">
                            <span class="color-name">FREE SPEECH AQUAMARINE</span>
                            <br>
                            <span class="hex-number">#03A678</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#4DAF7C;">
                            <span class="color-name">OCEAN GREEN</span>
                            <br>
                            <span class="hex-number">#4DAF7C</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#D9B611;">
                            <span class="color-name">Patrinia flowers</span>
                            <br>
                            <span class="hex-number">#D9B611</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F3C13A;">
                            <span class="color-name">Amur cork tree</span>
                            <br>
                            <span class="hex-number">#F3C13A</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F7CA18;">
                            <span class="color-name">RIPE LEMON</span>
                            <br>
                            <span class="hex-number">#F7CA18</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#E2B13C;">
                            <span class="color-name">Japanese triandra grass</span>
                            <br>
                            <span class="hex-number">#E2B13C</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#A17917;">
                            <span class="color-name">Rapeseed oil-colored</span>
                            <br>
                            <span class="hex-number">#A17917</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F5D76E;">
                            <span class="color-name">CREAM CAN</span>
                            <br>
                            <span class="hex-number">#F5D76E</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F4D03F;">
                            <span class="color-name">SAFFRON</span>
                            <br>
                            <span class="hex-number">#F4D03F</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FFA400;">
                            <span class="color-name">Bright golden yellow</span>
                            <br>
                            <span class="hex-number">#FFA400</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#E08A1E;">
                            <span class="color-name">Sumac-dyed</span>
                            <br>
                            <span class="hex-number">#E08A1E</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FFB61E;">
                            <span class="color-name">Gamboge</span>
                            <br>
                            <span class="hex-number">#FFB61E</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FAA945;">
                            <span class="color-name">Corn-colored</span>
                            <br>
                            <span class="hex-number">#FAA945</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FFA631;">
                            <span class="color-name">Egg-colored</span>
                            <br>
                            <span class="hex-number">#FFA631</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#FFB94E;">
                            <span class="color-name">Floral leaf-colored</span>
                            <br>
                            <span class="hex-number">#FFB94E</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#E29C45;">
                            <span class="color-name">Golden fallen leaves</span>
                            <br>
                            <span class="hex-number">#E29C45</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F9690E;">
                            <span class="color-name">ECSTASY</span>
                            <br>
                            <span class="hex-number">#F9690E</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #CA6924;">
                            <span class="color-name">Amber</span>
                            <br>
                            <span class="hex-number">#CA6924</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F5AB35;">
                            <span class="color-name">LIGHTNING YELLOW</span>
                            <br>
                            <span class="hex-number">#F5AB35</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#BFBFBF;">
                            <span class="color-name">SILVER</span>
                            <br>
                            <span class="hex-number">#BFBFBF</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#F2F1EF;">
                            <span class="color-name">CARARRA</span>
                            <br>
                            <span class="hex-number">#F2F1EF</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#BDC3C7;">
                            <span class="color-name">SILVER SAND</span>
                            <br>
                            <span class="hex-number">#BDC3C7</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#ECF0F1;">
                            <span class="color-name">PORCELAIN</span>
                            <br>
                            <span class="hex-number">#ECF0F1</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#D2D7D3;">
                            <span class="color-name">PUMICE</span>
                            <br>
                            <span class="hex-number">#D2D7D3</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#757D75;">
                            <span class="color-name">Harbor rat</span>
                            <br>
                            <span class="hex-number">#757D75</span>
                            <br>
                          </div>
                        </div>

                        <div class="color-picker">
                          <div class="color-item" style="background-color:#EEEEEE;">
                            <span class="color-name">GALLERY</span>
                            <br>
                            <span class="hex-number">#EEEEEE</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#ABB7B7;">
                            <span class="color-name">EDWARD</span>
                            <br>
                            <span class="hex-number">#ABB7B7</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color: #6C7A89;">
                            <span class="color-name">LYNCH</span>
                            <br>
                            <span class="hex-number">#6C7A89</span>
                            <br>
                          </div>
                        </div>
                        <div class="color-picker">
                          <div class="color-item" style="background-color:#95A5A6;">
                            <span class="color-name">CASCADE</span>
                            <br>
                            <span class="hex-number">#95A5A6</span>
                            <br>
                          </div>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>

              </div><!-- panel body -->
            </div>
        </div><!-- content -->
      </div>
    </div>
    <!--footer-->
    <div class="site-footer">
      <div class="container">
        <div class="download">
          <span class="download__infos">You simply have to <b>try it</b>.</span>&nbsp;&nbsp;&nbsp;&nbsp;
          <a class="btn btn-primary" href="https://github.com/silverbux/bootflat-admin/archive/master.zip">Download Bootflat-Admin</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <!-- SmartAddon BEGIN -->
            <script type="text/javascript">
            (function() {
            var s=document.createElement('script');s.type='text/javascript';s.async = true;
            s.src='http://s1'+'.smartaddon.com/share_addon.js';
            var j =document.getElementsByTagName('script')[0];j.parentNode.insertBefore(s,j);
            })();
            </script>

            <a href="http://www.smartaddon.com/?share" title="Share Button" onclick="return sa_tellafriend('','bookmarks')"><img alt="Share" src="http://bootflat.github.io/img/share.gif" border="0" /></a>
            <!-- SmartAddon END -->
        </div>
        <hr class="dashed" />
        <div class="row">
          <div class="col-md-4">
            <h3>Get involved</h3>
            <p>Bootflat is hosted on <a href="https://github.com/silverbux/bootflat-admin" target="_blank" rel="external nofollow">GitHub</a> and open for everyone to contribute. Please give us some feedback and join the development!</p>
          </div>
          <div class="col-md-4">
            <h3>Contribute</h3>
            <p>You want to help us and participate in the development or the documentation? Just fork Bootflat on <a href="https://github.com/silverbux/bootflat-admin" target="_blank" rel="external nofollow">GitHub</a> and send us a pull request.</p>
          </div>
          <div class="col-md-4">
            <h3>Found a bug?</h3>
            <p>Open a <a href="https://github.com/silverbux/bootflat-admin/issues" target="_blank" rel="external nofollow">new issue</a> on GitHub. Please search for existing issues first and make sure to include all relevant information.</p>
          </div>
        </div>
        <hr class="dashed" />
        <div class="row">
          <div class="col-md-6">
            <h3>Talk to us</h3>
            <ul>
              <li>Tweet us at <a href="https://twitter.com" target="_blank">@YourTwitter</a>&nbsp;&nbsp;&nbsp;&nbsp;Email us at <span class="connect">info@yourdomain.com</span></li>
              <li>
                <a title="Twitter" href="https://twitter.com" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe121"></i></a>
                <a title="Facebook" href="https://www.facebook.com" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe10b"></i></a>
                <a title="Google+" href="https://plus.google.com/" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe110"></i></a>
                <a title="Github" href="https://github.com/alexquiambao" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe10e"></i></a>
              </li>
            </ul>
          </div>
          <div class="col-md-6">
            <!-- Begin MailChimp Signup Form -->
            <link href="//cdn-images.mailchimp.com/embedcode/slim-081711.css" rel="stylesheet" type="text/css">
            <div id="mc_embed_signup">
            <h3 style="margin-bottom: 15px;">Newsletter</h3>
            <form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" novalidate>
                <input style="margin-bottom: 10px;" type="email" value="" name="EMAIL" class="email form-control" id="mce-EMAIL" placeholder="email address" required>
                <span class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn btn-primary"></span>
            </form>
            </div>
            <!--End mc_embed_signup-->
          </div>
        </div>
        <hr class="dashed" />
        <div class="copyright clearfix">
          <p><b>Bootflat</b>&nbsp;&nbsp;&nbsp;&nbsp;<a href="getting-started.php">Getting Started</a>&nbsp;&bull;&nbsp;<a href="index.php">Documentation</a>&nbsp;&bull;&nbsp;<a href="https://github.com/Bootflat/Bootflat.UI.Kit.PSD/archive/master.zip">Free PSD</a>&nbsp;&bull;&nbsp;<a href="colors.php">Color Picker</a></p>
          <p>Code licensed under <a href="http://opensource.org/licenses/mit-license.php" target="_blank" rel="external nofollow">MIT License</a>, documentation under <a href="http://creativecommons.org/licenses/by/3.0/" rel="external nofollow">CC BY 3.0</a>.</p>
        </div>
      </div>
    </div>
  </body>
</html>
