<?php
// mysql_connect("localhost","root","1990");
// mysql_select_db("school");
// $id=$_GET['id'];
// $query="select * from file where id='$id'";
// $query1=mysql_query($query);
// while($ros=mysql_fetch_array($query1))
// {
// 	$path=$ros['path'];
// 	header('content-Disposition:attachment; filename='.$path.'');
// 	header('content-type:application/octent-strem');
// 	header('content-length='.filesize($path));
// 	readfile($path);
// }

$con=mysqli_connect("localhost","root","1990","school");
$id=$_GET['id'];
$query1=mysqli_query($con,"select * from file where id='$id'");
while($ros=mysqli_fetch_array($query1))
{
	$path=$ros['path'];
	header('content-Disposition:attachment; filename='.$path.'');
	header('content-type:application/octent-strem');
	header('content-length='.filesize($path));
	readfile($path);
}
?>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>